#!/usr/bin/env node
// AgentMint evidence package verifier. STANDALONE. Requires only Node >= 18.
// Checks: plan signature, every receipt signature, previous_receipt_hash
// links (AERF SPEC.md §8.4), seq continuity, and the chain root in
// receipt_index.json. Exit 0 = every check passed.
import { createHash, createPublicKey, verify as edVerify } from "node:crypto";
import { readFileSync, existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const here = dirname(fileURLToPath(import.meta.url));

// Number-preserving JSON parse (like Go's json.Number).
function parsePreserving(src) {
  let i = 0;
  const ws = () => { while (i < src.length && /[\s]/.test(src[i])) i++; };
  function value() {
    ws();
    const c = src[i];
    if (c === "{") return obj();
    if (c === "[") return arr();
    if (c === '"') return str();
    if (c === "t") { i += 4; return true; }
    if (c === "f") { i += 5; return false; }
    if (c === "n") { i += 4; return null; }
    return num();
  }
  function obj() {
    i++; const out = new Map(); ws();
    if (src[i] === "}") { i++; return out; }
    for (;;) {
      ws(); const k = str(); ws(); i++;
      out.set(k, value()); ws();
      if (src[i] === ",") { i++; continue; }
      i++; return out;
    }
  }
  function arr() {
    i++; const out = []; ws();
    if (src[i] === "]") { i++; return out; }
    for (;;) {
      out.push(value()); ws();
      if (src[i] === ",") { i++; continue; }
      i++; return out;
    }
  }
  function str() {
    let out = ""; i++;
    while (src[i] !== '"') {
      if (src[i] === "\\") {
        const e = src[i + 1];
        if (e === "u") { out += String.fromCharCode(parseInt(src.slice(i + 2, i + 6), 16)); i += 6; }
        else { out += ({ '"': '"', "\\": "\\", "/": "/", b: "\b", f: "\f", n: "\n", r: "\r", t: "\t" })[e]; i += 2; }
      } else { out += src[i++]; }
    }
    i++; return out;
  }
  function num() {
    const start = i;
    while (i < src.length && /[-+0-9.eE]/.test(src[i])) i++;
    return { __num: src.slice(start, i) };
  }
  return value();
}

function esc(s) {
  let out = '"';
  for (const ch of s.normalize("NFC")) {
    const code = ch.codePointAt(0);
    if (ch === '"') out += '\\"';
    else if (ch === "\\") out += "\\\\";
    else if (ch === "\b") out += "\\b";
    else if (ch === "\f") out += "\\f";
    else if (ch === "\n") out += "\\n";
    else if (ch === "\r") out += "\\r";
    else if (ch === "\t") out += "\\t";
    else if (code < 0x20) out += "\\u" + code.toString(16).padStart(4, "0");
    else out += ch;
  }
  return out + '"';
}
function canonical(v) {
  if (v === null) return "null";
  if (v === true) return "true";
  if (v === false) return "false";
  if (typeof v === "string") return esc(v);
  if (v && v.__num !== undefined) return v.__num;
  if (Array.isArray(v)) return "[" + v.map(canonical).join(",") + "]";
  if (v instanceof Map) {
    const keys = [...v.keys()].sort();
    return "{" + keys.map((k) => esc(k) + ":" + canonical(v.get(k))).join(",") + "}";
  }
  throw new Error("unsupported type");
}

const POST_ISSUANCE = ["signature", "timestamp", "parent_signature", "parent_key_id", "log_inclusion_proof"];
const sha256 = (buf) => createHash("sha256").update(buf).digest("hex");

function strippedPayload(receiptMap) {
  const stripped = new Map(receiptMap);
  for (const f of POST_ISSUANCE) stripped.delete(f);
  return Buffer.from(canonical(stripped), "utf-8");
}

const pub = createPublicKey(readFileSync(join(here, "public_key.pem"), "utf-8"));
const index = JSON.parse(readFileSync(join(here, "receipt_index.json"), "utf-8"));
let failures = 0;
const fail = (msg) => { failures++; console.error("  FAIL  " + msg); };
const ok = (msg) => console.log("  ok    " + msg);

// 1. Plan signature.
const planPath = join(here, "plan.json");
if (existsSync(planPath)) {
  const plan = parsePreserving(readFileSync(planPath, "utf-8"));
  const sig = plan.get("signature");
  const planStripped = new Map(plan);
  planStripped.delete("signature");
  const valid = edVerify(null, Buffer.from(canonical(planStripped), "utf-8"), pub, Buffer.from(sig, "hex"));
  valid ? ok("plan signature") : fail("plan signature INVALID");
}

// 2. Receipts: signatures + chain links + seq, in index order.
let expectedPrev = undefined;
let prevSeq = undefined;
for (const entry of index.receipts) {
  const receipt = parsePreserving(readFileSync(join(here, entry.file), "utf-8"));
  const id = receipt.get("id");
  const payload = strippedPayload(receipt);
  const sigOk = edVerify(null, payload, pub, Buffer.from(receipt.get("signature"), "hex"));
  sigOk ? ok("signature  " + id.slice(0, 8) + "  " + receipt.get("action")) : fail("signature INVALID for " + id);

  const declaredPrev = receipt.has("previous_receipt_hash") ? receipt.get("previous_receipt_hash") : undefined;
  if (declaredPrev !== expectedPrev) fail("chain link broken at " + id + " (a receipt was removed or reordered)");
  const seq = receipt.has("seq") ? Number(receipt.get("seq").__num ?? receipt.get("seq")) : undefined;
  if (seq !== undefined && prevSeq !== undefined && seq !== prevSeq + 1) fail("seq gap at " + id + ": expected " + (prevSeq + 1) + ", got " + seq);
  if (seq !== undefined) prevSeq = seq;
  expectedPrev = sha256(payload);
}

// 3. Chain root matches the index.
if (index.chain && index.chain.root_hash) {
  index.chain.root_hash === (expectedPrev ?? "")
    ? ok("chain root " + index.chain.root_hash.slice(0, 16) + "…")
    : fail("chain root mismatch: index says " + index.chain.root_hash + ", recomputed " + (expectedPrev ?? "<empty>"));
}

console.log("");
if (failures > 0) {
  console.error(failures + " check(s) FAILED");
  process.exit(1);
}
console.log("All checks passed: " + index.receipts.length + " receipt(s), chain intact.");
